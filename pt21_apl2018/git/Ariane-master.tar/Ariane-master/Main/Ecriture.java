  /*      import javax.swing.*;
        import java.awt.*;
        import java.awt.event.*;
        import java.io.*;
        import java.util.*;
              
        public class Ecriture {
    	
    		private int[] tab = null;
    		private int[] details = new int[5];

           public Ecriture(int[] tab, int[] details)  { 
           		super();
           		this.taille=tab;
           		this.details=details;

                try{
                    FileOutputStream ecri = new FileOutputStream("Sauvegarde.lab");
                    DataOutputStream d = new DataOutputStream(ecri);

                    System.out.println(details[0]);
      
                     d.close();
            	} catch (FileNotFoundException e){
                         System.err.println("file not found ");
                    }catch (IOException e){
                        System.err.println("Pb IO");
                    }
            }
        }
*/